{
    "_entries": {
        "7fd31da74891955d42beeca52e802ee2": {
            "_j": "DataCube.Model.SqlSource",
            "_n": "База",
            "_ct": 1773765291225,
            "_ut": 1773765587081,
            "_v": 4,
            "_p": "0bba0da14824a649285a97641a0a0cc1",
            "_e": 0,
            "_l": false
        },
        "eb0dea3d9cb3ca5f3939546debbf71ed": {
            "_j": "DataCube.Model.SqlSchema",
            "_n": "public",
            "_ct": 1773765586066,
            "_ut": 1773765587072,
            "_v": 1,
            "_p": "7fd31da74891955d42beeca52e802ee2",
            "_e": 0,
            "_l": false
        },
        "eccb7a939d2ad5539a9540d821bbf03e": {
            "_j": "DataCube.Model.SqlTable",
            "_n": "public.auth_group",
            "_ct": 1773765586070,
            "_ut": 1773765587098,
            "_v": 1,
            "_p": "eb0dea3d9cb3ca5f3939546debbf71ed",
            "_e": 0,
            "_l": false
        },
        "8cba9a1d23aa7ee69edcc96a318f8fab": {
            "_j": "DataCube.Model.SqlTable",
            "_n": "public.auth_group_permissions",
            "_ct": 1773765586076,
            "_ut": 1773765587107,
            "_v": 1,
            "_p": "eb0dea3d9cb3ca5f3939546debbf71ed",
            "_e": 0,
            "_l": false
        },
        "bb38c4b3febd7513d8f12d45a8cd867f": {
            "_j": "DataCube.Model.SqlTable",
            "_n": "public.auth_permission",
            "_ct": 1773765586084,
            "_ut": 1773765587115,
            "_v": 1,
            "_p": "eb0dea3d9cb3ca5f3939546debbf71ed",
            "_e": 0,
            "_l": false
        },
        "f84237dd569e4b339f22841c4fb03235": {
            "_j": "DataCube.Model.SqlTable",
            "_n": "public.auth_user",
            "_ct": 1773765586091,
            "_ut": 1773765587124,
            "_v": 1,
            "_p": "eb0dea3d9cb3ca5f3939546debbf71ed",
            "_e": 0,
            "_l": false
        },
        "8505bac8439313b9a9a56668955e2953": {
            "_j": "DataCube.Model.SqlTable",
            "_n": "public.auth_user_groups",
            "_ct": 1773765586099,
            "_ut": 1773765587132,
            "_v": 1,
            "_p": "eb0dea3d9cb3ca5f3939546debbf71ed",
            "_e": 0,
            "_l": false
        },
        "2ff6d0f8f8fe05d917d09f94f58a890c": {
            "_j": "DataCube.Model.SqlTable",
            "_n": "public.auth_user_user_permissions",
            "_ct": 1773765586107,
            "_ut": 1773765587140,
            "_v": 1,
            "_p": "eb0dea3d9cb3ca5f3939546debbf71ed",
            "_e": 0,
            "_l": false
        },
        "36258a0887149120c7aa779f73c77a84": {
            "_j": "DataCube.Model.SqlTable",
            "_n": "public.diseases_absolute",
            "_ct": 1773765586114,
            "_ut": 1773765587148,
            "_v": 1,
            "_p": "eb0dea3d9cb3ca5f3939546debbf71ed",
            "_e": 0,
            "_l": false
        },
        "5c9a2678ecd57f907ebba37f49fe3ab1": {
            "_j": "DataCube.Model.SqlTable",
            "_n": "public.diseases_per_1000",
            "_ct": 1773765586121,
            "_ut": 1773765587155,
            "_v": 1,
            "_p": "eb0dea3d9cb3ca5f3939546debbf71ed",
            "_e": 0,
            "_l": false
        },
        "7d42b7259ffba04c3cc5550912178fb1": {
            "_j": "DataCube.Model.SqlTable",
            "_n": "public.django_admin_log",
            "_ct": 1773765586127,
            "_ut": 1773765587162,
            "_v": 1,
            "_p": "eb0dea3d9cb3ca5f3939546debbf71ed",
            "_e": 0,
            "_l": false
        },
        "a8e5072d736cfc9322571c7875a40289": {
            "_j": "DataCube.Model.SqlTable",
            "_n": "public.django_content_type",
            "_ct": 1773765586136,
            "_ut": 1773765587171,
            "_v": 1,
            "_p": "eb0dea3d9cb3ca5f3939546debbf71ed",
            "_e": 0,
            "_l": false
        },
        "db18662ffb6758ee0c325ef49b792e6a": {
            "_j": "DataCube.Model.SqlTable",
            "_n": "public.django_migrations",
            "_ct": 1773765586142,
            "_ut": 1773765587178,
            "_v": 1,
            "_p": "eb0dea3d9cb3ca5f3939546debbf71ed",
            "_e": 0,
            "_l": false
        },
        "1180ea818699d40a40a0f40b287adb5f": {
            "_j": "DataCube.Model.SqlTable",
            "_n": "public.django_session",
            "_ct": 1773765586149,
            "_ut": 1773765587184,
            "_v": 1,
            "_p": "eb0dea3d9cb3ca5f3939546debbf71ed",
            "_e": 0,
            "_l": false
        },
        "0d1177f302acd087057ef89e67415661": {
            "_j": "DataCube.Model.SqlTable",
            "_n": "public.income_expenses",
            "_ct": 1773765586157,
            "_ut": 1773765587192,
            "_v": 1,
            "_p": "eb0dea3d9cb3ca5f3939546debbf71ed",
            "_e": 0,
            "_l": false
        },
        "07999de0f9ec3aabd946b8eb05d555eb": {
            "_j": "DataCube.Model.SqlTable",
            "_n": "public.inflation_diseaseincidence",
            "_ct": 1773765586164,
            "_ut": 1773765587201,
            "_v": 1,
            "_p": "eb0dea3d9cb3ca5f3939546debbf71ed",
            "_e": 0,
            "_l": false
        },
        "139513f3741608832ddb18f54faef9dd": {
            "_j": "DataCube.Model.SqlTable",
            "_n": "public.inflation_incomeexpenses",
            "_ct": 1773765586172,
            "_ut": 1773765587212,
            "_v": 1,
            "_p": "eb0dea3d9cb3ca5f3939546debbf71ed",
            "_e": 0,
            "_l": false
        },
        "99132a5d875964fb0983ac7e70a1755d": {
            "_j": "DataCube.Model.SqlTable",
            "_n": "public.inflation_incomeshare",
            "_ct": 1773765586179,
            "_ut": 1773765587222,
            "_v": 1,
            "_p": "eb0dea3d9cb3ca5f3939546debbf71ed",
            "_e": 0,
            "_l": false
        },
        "7271d2f21838ff7de7eecd679fb80303": {
            "_j": "DataCube.Model.SqlTable",
            "_n": "public.inflation_medicalpersonnel",
            "_ct": 1773765586186,
            "_ut": 1773765587235,
            "_v": 1,
            "_p": "eb0dea3d9cb3ca5f3939546debbf71ed",
            "_e": 0,
            "_l": false
        },
        "198eb205a2663c898577ad4fac8f1f32": {
            "_j": "DataCube.Model.SqlTable",
            "_n": "public.inflation_monthlyinflation",
            "_ct": 1773765586193,
            "_ut": 1773765587245,
            "_v": 1,
            "_p": "eb0dea3d9cb3ca5f3939546debbf71ed",
            "_e": 0,
            "_l": false
        },
        "085cc5900eb34fd623f2a4777c1a49a0": {
            "_j": "DataCube.Model.SqlTable",
            "_n": "public.interest_rates",
            "_ct": 1773765586207,
            "_ut": 1773765587256,
            "_v": 1,
            "_p": "eb0dea3d9cb3ca5f3939546debbf71ed",
            "_e": 0,
            "_l": false
        },
        "8f46d049e031fb82437f166346bde553": {
            "_j": "DataCube.Model.SqlTable",
            "_n": "public.medical_doctors",
            "_ct": 1773765586214,
            "_ut": 1773765587265,
            "_v": 1,
            "_p": "eb0dea3d9cb3ca5f3939546debbf71ed",
            "_e": 0,
            "_l": false
        },
        "3c67a67d4ae8c2c28b96d43c8c0bc090": {
            "_j": "DataCube.Model.SqlTable",
            "_n": "public.medical_staff",
            "_ct": 1773765586220,
            "_ut": 1773765587273,
            "_v": 1,
            "_p": "eb0dea3d9cb3ca5f3939546debbf71ed",
            "_e": 0,
            "_l": false
        },
        "f652295f361402111d635965f39ad8a1": {
            "_j": "DataCube.Model.SqlTable",
            "_n": "public.monthly_inflation",
            "_ct": 1773765586227,
            "_ut": 1773765587280,
            "_v": 1,
            "_p": "eb0dea3d9cb3ca5f3939546debbf71ed",
            "_e": 0,
            "_l": false
        },
        "ddef35f41900b47bec932af164d92420": {
            "_j": "DataCube.Model.Cube",
            "_n": "Куб",
            "_ct": 1773929682775,
            "_ut": 1774112756974,
            "_v": 88,
            "_p": "0bba0da14824a649285a97641a0a0cc1",
            "_e": 0,
            "_l": false
        },
        "c3033c1504b2dc4b9b29a814863dd72c": {
            "_j": "DataCube.Model.Slice",
            "_n": "public.income_expenses",
            "_ct": 1773932298073,
            "_ut": 1774020474918,
            "_v": 6,
            "_p": "ddef35f41900b47bec932af164d92420",
            "_e": 0
        },
        "a3e6796d0d228b5e8840258e73fc3017": {
            "_j": "DataCube.Model.Slice",
            "_n": "Срез",
            "_ct": 1773932428365,
            "_ut": 1774020474911,
            "_v": 7,
            "_p": "ddef35f41900b47bec932af164d92420",
            "_e": 0
        },
        "c79ea7f09ff1dca3a9fda857f86bfb98": {
            "_j": "DataCube.Model.Widget",
            "_n": "Доходы в г. Москва по годам",
            "_ct": 1773944726592,
            "_ut": 1774020474923,
            "_v": 5,
            "_p": "ddef35f41900b47bec932af164d92420",
            "_i": {
                "wType": "DataCube.Widgets.LineChart"
            },
            "_e": 0
        },
        "b228df4e071d3301bc96b3f8b84bd616": {
            "_j": "DataCube.Model.Slice",
            "_n": "public.monthly_inflation",
            "_ct": 1774000789071,
            "_ut": 1774020505317,
            "_v": 8,
            "_p": "ddef35f41900b47bec932af164d92420",
            "_e": 0
        },
        "9c53de938a6009a7440e7dfc7013f77a": {
            "_j": "DataCube.Model.Slice",
            "_n": "Месяцы",
            "_ct": 1774007919923,
            "_ut": 1774020504292,
            "_v": 9,
            "_p": "ddef35f41900b47bec932af164d92420",
            "_e": 0
        },
        "406ea363df435da30d46e5bf02e85e91": {
            "_j": "DataCube.Model.Widget",
            "_n": "Кнопка",
            "_ct": 1774007982885,
            "_ut": 1774020499051,
            "_v": 7,
            "_p": "ddef35f41900b47bec932af164d92420",
            "_i": {
                "wType": "DataCube.Widgets.Button"
            },
            "_e": 0
        },
        "35482680bc17d25f5f1e2a0516426224": {
            "_j": "DataCube.Model.Slice",
            "_n": "Инфляция по месяцам",
            "_ct": 1774008301184,
            "_ut": 1774009665808,
            "_v": 11,
            "_p": "ddef35f41900b47bec932af164d92420",
            "_e": 0
        },
        "c6a63da25127d79597c8df7b62d0b39f": {
            "_j": "DataCube.Model.Slice",
            "_n": "Выбранный месяц",
            "_ct": 1774008977948,
            "_ut": 1774009843305,
            "_v": 9,
            "_p": "ddef35f41900b47bec932af164d92420",
            "_e": 0
        },
        "93155112cbea8ad393bcaeb9b291a498": {
            "_j": "Cubisio.Model.DashboardDesign",
            "_n": "Дашборд",
            "_ct": 1774013651535,
            "_ut": 1774112972601,
            "_v": 24,
            "_p": "0bba0da14824a649285a97641a0a0cc1",
            "_e": 0,
            "_l": false
        },
        "987dd2d97df8552975517906290c15ea": {
            "_j": "DataCube.Model.Slice",
            "_n": "Инфляция для дашборда",
            "_ct": 1774014305668,
            "_ut": 1774020493987,
            "_v": 5,
            "_p": "ddef35f41900b47bec932af164d92420",
            "_e": 0
        },
        "411c701b69dcecfd32a686e50dabfd1d": {
            "_j": "DataCube.Model.Widget",
            "_n": "Диаграмма инфляции",
            "_ct": 1774015518794,
            "_ut": 1774020493994,
            "_v": 4,
            "_p": "ddef35f41900b47bec932af164d92420",
            "_i": {
                "wType": "DataCube.Widgets.LineChart"
            },
            "_e": 0
        },
        "21a3d8e79735dd0b756eaa540188b4a7": {
            "_j": "DataCube.Model.Widget",
            "_n": "Текст",
            "_ct": 1774015971227,
            "_ut": 1774015972248,
            "_v": 1,
            "_p": "93155112cbea8ad393bcaeb9b291a498",
            "_i": {
                "wType": "DataCube.Widgets.Text"
            },
            "_e": 0
        },
        "718e5e572ec0d8c500e77db08d58fabf": {
            "_j": "DataCube.Model.Widget",
            "_n": "Текст",
            "_ct": 1774016176268,
            "_ut": 1774016177285,
            "_v": 1,
            "_p": "93155112cbea8ad393bcaeb9b291a498",
            "_i": {
                "wType": "DataCube.Widgets.Text"
            },
            "_e": 0
        },
        "93e37e897296a7b60be99a570f1843cc": {
            "_j": "DataCube.Model.Slice",
            "_n": "public.interest_rates",
            "_ct": 1774016703820,
            "_ut": 1774020484212,
            "_v": 4,
            "_p": "ddef35f41900b47bec932af164d92420",
            "_e": 0
        },
        "cffe894498c38791d66b8baae0cf79a6": {
            "_j": "DataCube.Model.Widget",
            "_n": "Доля населения ниже прожиточного минимума в Москве(в процентах)",
            "_ct": 1774020022725,
            "_ut": 1774020484222,
            "_v": 5,
            "_p": "ddef35f41900b47bec932af164d92420",
            "_i": {
                "wType": "DataCube.Widgets.LineChart"
            },
            "_e": 0
        },
        "f9517e9727f774457e89d04682e9d1e6": {
            "_j": "DataCube.Model.Widget",
            "_n": "Текст",
            "_ct": 1774020301119,
            "_ut": 1774020302138,
            "_v": 1,
            "_p": "93155112cbea8ad393bcaeb9b291a498",
            "_i": {
                "wType": "DataCube.Widgets.Text"
            },
            "_e": 0
        },
        "6933565432ea57748134f258dfffcb9a": {
            "_j": "DataCube.Model.Slice",
            "_n": "public.diseases_absolute",
            "_ct": 1774020755160,
            "_ut": 1774110272176,
            "_v": 7,
            "_p": "ddef35f41900b47bec932af164d92420",
            "_e": 0
        },
        "18ccefd1d32240cc730cc81dc050c3e5": {
            "_j": "DataCube.Model.Slice",
            "_n": "Год(для болезней)",
            "_ct": 1774021170443,
            "_ut": 1774110272129,
            "_v": 8,
            "_p": "ddef35f41900b47bec932af164d92420",
            "_e": 0
        },
        "7ec0bf99a4b3224de03cf366449d19e2": {
            "_j": "DataCube.Model.Widget",
            "_n": "Кнопка(болезни)",
            "_ct": 1774021216202,
            "_ut": 1774110272184,
            "_v": 7,
            "_p": "ddef35f41900b47bec932af164d92420",
            "_i": {
                "wType": "DataCube.Widgets.Button"
            },
            "_e": 0
        },
        "1c35b0898d092efc682ba0282bc4212d": {
            "_j": "DataCube.Model.Slice",
            "_n": "Болезни по годам",
            "_ct": 1774021337571,
            "_ut": 1774110272192,
            "_v": 20,
            "_p": "ddef35f41900b47bec932af164d92420",
            "_e": 0
        },
        "51903e7de20be57aa23566027d8aaf7b": {
            "_j": "DataCube.Model.Slice",
            "_n": "Годы для дашборда",
            "_ct": 1774021755315,
            "_ut": 1774110272153,
            "_v": 10,
            "_p": "ddef35f41900b47bec932af164d92420",
            "_e": 0
        },
        "908a600d49ddafbe8e4e90b764974ff9": {
            "_j": "DataCube.Model.Widget",
            "_n": "Болезни по годам",
            "_ct": 1774108569054,
            "_ut": 1774110272142,
            "_v": 5,
            "_p": "ddef35f41900b47bec932af164d92420",
            "_i": {
                "wType": "DataCube.Widgets.Table"
            },
            "_e": 0
        },
        "173a9f92e498f7cff165e24bdd8b521f": {
            "_j": "DataCube.Model.Widget",
            "_n": "Текст",
            "_ct": 1774108950804,
            "_ut": 1774108951864,
            "_v": 1,
            "_p": "93155112cbea8ad393bcaeb9b291a498",
            "_i": {
                "wType": "DataCube.Widgets.Text"
            },
            "_e": 0
        },
        "99ca8bb4b1a184182d88c4aab51aa705": {
            "_j": "DataCube.Model.Widget",
            "_n": "Круговая диаграмма за определенный год",
            "_ct": 1774109732595,
            "_ut": 1774110272162,
            "_v": 4,
            "_p": "ddef35f41900b47bec932af164d92420",
            "_i": {
                "wType": "DataCube.Widgets.PieChart"
            },
            "_e": 0
        },
        "685f0ab054cbdfabc6eb373193139306": {
            "_j": "DataCube.Model.Slice",
            "_n": "public.inflation_medicalpersonnel",
            "_ct": 1774110523682,
            "_ut": 1774112205793,
            "_v": 8,
            "_p": "ddef35f41900b47bec932af164d92420",
            "_e": 0
        },
        "e594d7b89c2328201c3f25d3a1fcc2bf": {
            "_j": "DataCube.Model.Slice",
            "_n": "Вид персонала",
            "_ct": 1774110818069,
            "_ut": 1774112194902,
            "_v": 10,
            "_p": "ddef35f41900b47bec932af164d92420",
            "_e": 0
        },
        "a36eba815aba4d2526c9cca582282d98": {
            "_j": "DataCube.Model.Slice",
            "_n": "Абсолютное/значение на 1000",
            "_ct": 1774110825160,
            "_ut": 1774112194893,
            "_v": 8,
            "_p": "ddef35f41900b47bec932af164d92420",
            "_e": 0
        },
        "6eb037eb62c8b604978c96e9169a4f5e": {
            "_j": "DataCube.Model.Widget",
            "_n": "Кнопка(Персонал)",
            "_ct": 1774112033943,
            "_ut": 1774112913071,
            "_v": 9,
            "_p": "ddef35f41900b47bec932af164d92420",
            "_i": {
                "wType": "DataCube.Widgets.Button"
            },
            "_e": 0
        },
        "f80b05ddcc18f6dbf448cbbbe8ad5b27": {
            "_j": "DataCube.Model.Widget",
            "_n": "Кнопка(Абсолютное значение)",
            "_ct": 1774112109252,
            "_ut": 1774112919043,
            "_v": 8,
            "_p": "ddef35f41900b47bec932af164d92420",
            "_i": {
                "wType": "DataCube.Widgets.Button"
            },
            "_e": 0
        },
        "816e6a48fe0d043e1ea30fe843ac0be5": {
            "_j": "DataCube.Model.Slice",
            "_n": "Таюлица врачей и персонала",
            "_ct": 1774112256902,
            "_ut": 1774112487763,
            "_v": 8,
            "_p": "ddef35f41900b47bec932af164d92420",
            "_e": 0
        },
        "44b482d08e740bc32718a16d9a2de3f5": {
            "_j": "DataCube.Model.Slice",
            "_n": "Вид персонала для кнопки",
            "_ct": 1774112584528,
            "_ut": 1774112737510,
            "_v": 6,
            "_p": "ddef35f41900b47bec932af164d92420",
            "_e": 0
        },
        "402f0a9b2384f96411bc3ebbbbf1e203": {
            "_j": "DataCube.Model.Slice",
            "_n": "Вид значения для кнопки",
            "_ct": 1774112613963,
            "_ut": 1774112737503,
            "_v": 4,
            "_p": "ddef35f41900b47bec932af164d92420",
            "_e": 0
        },
        "a350bbf350d75a9ec6aef0b86d0c257f": {
            "_j": "DataCube.Model.Widget",
            "_n": "Врачи линейная диаграмма",
            "_ct": 1774112755946,
            "_ut": 1774112888361,
            "_v": 4,
            "_p": "ddef35f41900b47bec932af164d92420",
            "_i": {
                "wType": "DataCube.Widgets.LineChart"
            },
            "_e": 0
        },
        "1fc26b48708c266e9f03c187bdfe32da": {
            "_j": "DataCube.Model.Widget",
            "_n": "Текст",
            "_ct": 1774112971563,
            "_ut": 1774112972593,
            "_v": 1,
            "_p": "93155112cbea8ad393bcaeb9b291a498",
            "_i": {
                "wType": "DataCube.Widgets.Text"
            },
            "_e": 0
        }
    },
    "_wt": "user",
    "_backups": [],
    "_id": "0bba0da14824a649285a97641a0a0cc1",
    "_type": "JSB.Workspace.Workspace",
    "_props": {},
    "_name": "Практика",
    "_parent": null,
    "_owner": "224970@edu.fa.ru",
    "_shares": {},
    "_created": 1773765232883,
    "_updated": 1774112972617,
    "_version": 296,
    "_children": {
        "7fd31da74891955d42beeca52e802ee2": 1,
        "ddef35f41900b47bec932af164d92420": 1,
        "93155112cbea8ad393bcaeb9b291a498": 1
    },
    "_artifacts": {},
    "_sourceRead": false
}